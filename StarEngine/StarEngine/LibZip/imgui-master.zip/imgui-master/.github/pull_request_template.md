(Click "Preview" to turn any http URL into a clickable link)

PLEASE CAREFULLY READ:
https://github.com/ocornut/imgui/issues/2261

(Clear this template before submitting your PR)
